
from mrjob.job import MRJob
from mrjob.step import MRStep
from datetime import datetime

class MRAvgTripTime(MRJob):

    def steps(self):
        return [
            MRStep(mapper=self.mapper,
                   reducer=self.reducer)
        ]

    def mapper(self, _, line):
        try:
            fields = line.strip().split(",")

            # Skip header or bad lines
            if fields[0] == "VendorID" or len(fields) < 8:
                return

            # PULocationID is 8th column (0-based index 7)
            pulocation = fields[7]
            pickup_str = fields[1].split(".")[0]   # remove milliseconds
            dropoff_str = fields[2].split(".")[0]

            fmt = "%Y-%m-%d %H:%M:%S"
            pickup_dt = datetime.strptime(pickup_str, fmt)
            dropoff_dt = datetime.strptime(dropoff_str, fmt)

            trip_time = (dropoff_dt - pickup_dt).total_seconds()

            if trip_time >= 0:
                yield pulocation, (trip_time, 1)

        except Exception:
            pass  # ignore parsing errors

    def reducer(self, pulocation, values):
        total_time = 0
        count = 0
        for trip_time, n in values:
            total_time += trip_time
            count += n
        if count > 0:
            avg_time = total_time / count
            yield pulocation, avg_time

if __name__ == "__main__":
    MRAvgTripTime.run()

