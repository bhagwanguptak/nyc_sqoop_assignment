#!/usr/bin/env python3

import subprocess

# ================================
# PostgreSQL Connection Details
# ================================
PG_HOST = "database-1.cbka2ow8gavy.us-east-1.rds.amazonaws.com"
PG_PORT = "5432"
PG_DB = "postgres"
PG_USER = "postgres"
PG_PASS = "bhagwan747820"
PG_TABLE = "nyc_yellow_trip_data"

# HDFS staging directory
HDFS_STAGING_DIR = "/user/hadoop/nyc_trip_staging_csv"

# HBase table and column family
HBASE_TABLE = "yellow_tripdata"
HBASE_CF = "tripinfo"

# Number of mappers for parallel import
NUM_MAPPERS = 4

# ================================
# Helper function to run shell commands
# ================================
def run_cmd(cmd):
    print(f"Running: {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Error: {result.stderr}")
    else:
        print(result.stdout)
    return result.returncode

# ================================
# 1. Remove previous HDFS staging folder
# ================================
run_cmd(f"hdfs dfs -rm -r -f {HDFS_STAGING_DIR}")

# ================================
# 2. Sqoop import from PostgreSQL to HDFS
# ================================
sqoop_cmd = f"""
sqoop import \
--connect jdbc:postgresql://{PG_HOST}:{PG_PORT}/{PG_DB} \
--username {PG_USER} \
--password {PG_PASS} \
--table {PG_TABLE} \
--target-dir {HDFS_STAGING_DIR} \
--as-textfile \
--fields-terminated-by ',' \
--lines-terminated-by '\\n' \
--null-string '\\\\N' \
--null-non-string '\\\\N' \
--where "vendorid IS NOT NULL AND tpep_pickup_datetime IS NOT NULL" \
--split-by vendorid \
--num-mappers {NUM_MAPPERS}
"""
run_cmd(sqoop_cmd)

# ================================
# 3. HBase ImportTsv
# ================================
importtsv_cmd = f"""
hbase org.apache.hadoop.hbase.mapreduce.ImportTsv \
-Dimporttsv.separator=',' \
-Dimporttsv.columns="tripinfo:vendorid,tripinfo:tpep_pickup_datetime,tripinfo:tpep_dropoff_datetime,tripinfo:passenger_count,tripinfo:trip_distance,tripinfo:ratecodeid,tripinfo:store_and_fwd_flag,tripinfo:pulocationid,tripinfo:dolocationid,tripinfo:payment_type,tripinfo:fare_amount,tripinfo:extra,tripinfo:mta_tax,tripinfo:tip_amount,tripinfo:tolls_amount,tripinfo:improvement_surcharge,tripinfo:total_amount,tripinfo:congestion_surcharge,tripinfo:airport_fee,HBASE_ROW_KEY" \
{HBASE_TABLE} {HDFS_STAGING_DIR}
"""
run_cmd(importtsv_cmd)
