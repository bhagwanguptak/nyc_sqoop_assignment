#!/usr/bin/env python3
from mrjob.job import MRJob
from mrjob.step import MRStep

class PickupLocationRevenue(MRJob):

    def mapper(self, _, line):
        # Split CSV line
        parts = line.strip().split(',')
        try:
            pulocation = parts[7]  # PULocationID
            total_amount = parts[16]  # total_amount
            if total_amount == '' or total_amount.upper() == '\\N':
                total_amount = 0
            else:
                total_amount = float(total_amount)
            yield pulocation, total_amount
        except Exception:
            pass  # skip malformed lines

    def reducer(self, key, values):
        yield key, sum(values)

if __name__ == '__main__':
    PickupLocationRevenue.run()

