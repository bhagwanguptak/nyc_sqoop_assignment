from mrjob.job import MRJob
import csv
from io import StringIO

class PaymentTypeCount(MRJob):

    def mapper(self, _, line):
        # Use csv reader to handle commas properly
        reader = csv.reader(StringIO(line))
        for row in reader:
            try:
                payment_type = row[9]  # Adjust column index if your CSV schema is different
                yield payment_type, 1
            except IndexError:
                pass  # Skip invalid lines

    def reducer(self, key, values):
        yield key, sum(values)

if __name__ == '__main__':
    PaymentTypeCount.run()

