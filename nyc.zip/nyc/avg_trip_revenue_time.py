from mrjob.job import MRJob
from mrjob.step import MRStep
from datetime import datetime

class MRAvgTripRevenueTime(MRJob):

    def steps(self):
        return [
            MRStep(mapper=self.mapper,
                   reducer=self.reducer)
        ]

    def mapper(self, _, line):
        # Skip header
        if line.startswith("VendorID"):
            return

        fields = line.strip().split(",")

        try:
            pickup_str = fields[1]
            fare_str = fields[10]

            # Skip rows with null fare
            if fare_str == "\\N" or fare_str == "":
                return

            fare_amount = float(fare_str)

            # Parse pickup datetime
            pickup_dt = datetime.strptime(pickup_str.split(".")[0], "%Y-%m-%d %H:%M:%S")

            # Month: YYYY-MM
            month = pickup_dt.strftime("%Y-%m")

            # Day vs Night (06-18 = Day, else Night)
            hour = pickup_dt.hour
            day_night = "Day" if 6 <= hour < 18 else "Night"

            # Weekday vs Weekend
            weekday = pickup_dt.weekday()  # 0 = Monday
            week_type = "Weekday" if weekday < 5 else "Weekend"

            # Composite key
            key = (month, day_night, week_type)

            yield key, (fare_amount, 1)

        except Exception:
            pass  # skip bad lines

    def reducer(self, key, values):
        total_fare = 0.0
        total_trips = 0
        for fare, count in values:
            total_fare += fare
            total_trips += count
        if total_trips > 0:
            avg_fare = total_fare / total_trips
            yield key, avg_fare

if __name__ == "__main__":
    MRAvgTripRevenueTime.run()

