from mrjob.job import MRJob

class VendorRevenue(MRJob):

    def mapper(self, _, line):
        try:
            fields = line.strip().split(',')
            vendorid = fields[0]
            fare = float(fields[10])
            extra = float(fields[11])
            mta_tax = float(fields[12])
            tip = float(fields[13])
            tolls = float(fields[14])
            surcharge = float(fields[15])
            revenue = fare + extra + mta_tax + tip + tolls + surcharge
            yield vendorid, (1, revenue)
        except:
            pass

    def reducer(self, vendorid, values):
        total_trips = 0
        total_revenue = 0
        for trips, revenue in values:
            total_trips += trips
            total_revenue += revenue
        yield vendorid, (total_trips, total_revenue)

if __name__ == '__main__':
    VendorRevenue.run()

