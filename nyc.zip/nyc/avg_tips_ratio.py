from mrjob.job import MRJob
from mrjob.step import MRStep

class MRAvgTipsRatio(MRJob):

    def steps(self):
        return [
            MRStep(mapper=self.mapper,
                   reducer=self.reducer)
        ]

    def mapper(self, _, line):
        # Skip header
        if line.startswith("VendorID"):
            return
        fields = line.strip().split(",")
        try:
            pulocation = fields[7]
            fare_amount = float(fields[10]) if fields[10] else 0.0
            tip_amount = float(fields[13]) if fields[13] else 0.0
            if fare_amount > 0:
                yield pulocation, (tip_amount, fare_amount)
        except:
            pass  # ignore bad rows

    def reducer(self, pulocation, values):
        total_tip = 0.0
        total_fare = 0.0
        for tip, fare in values:
            total_tip += tip
            total_fare += fare
        if total_fare > 0:
            avg_ratio = total_tip / total_fare
            yield pulocation, avg_ratio

if __name__ == "__main__":
    MRAvgTipsRatio.run()

