#!/bin/bash

# =============================================
# Sqoop -> HDFS Staging -> HBase Bulk Load Script
# =============================================

# PostgreSQL Connection Details
PG_HOST="database-1.cbka2ow8gavy.us-east-1.rds.amazonaws.com"
PG_PORT="5432"
PG_DB="postgres"
PG_USER="postgres"
PG_PASS="bhagwan747820"
PG_TABLE="nyc_yellow_trip_data"

# HDFS staging directory
HDFS_STAGING_DIR="/user/hadoop/nyc_trip_staging_csv"

# HBase table and column family
HBASE_TABLE="yellow_tripdata"
HBASE_CF="tripinfo"

# Number of mappers for parallel import
NUM_MAPPERS=4

# 1️  Remove previous staging folder if exists
hdfs dfs -rm -r -f $HDFS_STAGING_DIR

# 2 Sqoop import from PostgreSQL to HDFS staging (as CSV)
sqoop import \
--connect jdbc:postgresql://$PG_HOST:$PG_PORT/$PG_DB \
--username $PG_USER \
--password $PG_PASS \
--table $PG_TABLE \
--target-dir $HDFS_STAGING_DIR \
--as-textfile \
--fields-terminated-by ',' \
--lines-terminated-by '\n' \
--null-string '\\N' \
--null-non-string '\\N' \
--where "vendorid IS NOT NULL AND tpep_pickup_datetime IS NOT NULL" \
--split-by vendorid \
--num-mappers $NUM_MAPPERS

# 3️ Optional: inspect first few lines
echo "Preview of HDFS staging CSV:"
hdfs dfs -cat $/user/hadoop/nyc_trip_staging_csv | head -n 10

# 4️ Bulk load into HBase using ImportTsv
#    Ensure your CSV has the first column as row-key: vendorid_tpep_pickup_datetime
#hbase org.apache.hadoop.hbase.mapreduce.ImportTsv \
#-Dimporttsv.separator=',' \
#-Dimporttsv.columns="HBASE_ROW_KEY,$HBASE_CF:vendorid,$HBASE_CF:tpep_pickup_datetime,$HBASE_CF:tpep_dropoff_datetime,$HBASE_CF:passenger_count,$HBASE_CF:trip_distance,$HBASE_CF:ratecodeid,$HBASE_CF:store_and_fwd_flag,$HBASE_CF:pulocationid,$HBASE_CF:dolocationid,$HBASE_CF:payment_type,$HBASE_CF:fare_amount,$HBASE_CF:extra,$HBASE_CF:mta_tax,$HBASE_CF:tip_amount,$HBASE_CF:tolls_amount,$HBASE_CF:improvement_surcharge,$HBASE_CF:total_amount,$HBASE_CF:congestion_surcharge,$HBASE_CF:airport_fee" \
#$HBASE_TABLE $HDFS_STAGING_DIR

hbase org.apache.hadoop.hbase.mapreduce.ImportTsv \
-Dimporttsv.separator=',' \
-Dimporttsv.columns="HBASE_ROW_KEY,tripinfo:vendorid,tripinfo:tpep_pickup_datetime,tripinfo:tpep_dropoff_datetime,tripinfo:passenger_count,tripinfo:trip_distance,tripinfo:ratecodeid,tripinfo:store_and_fwd_flag,tripinfo:pulocationid,tripinfo:dolocationid,tripinfo:payment_type,tripinfo:fare_amount,tripinfo:extra,tripinfo:mta_tax,tripinfo:tip_amount,tripinfo:tolls_amount,tripinfo:improvement_surcharge,tripinfo:total_amount,tripinfo:congestion_surcharge,tripinfo:airport_fee" \
yellow_tripdata /user/hadoop/nyc_trip_staging_csv

hbase org.apache.hadoop.hbase.mapreduce.ImportTsv \
  -Dimporttsv.separator=',' \
  -Dimporttsv.columns="tripinfo:vendorid,tripinfo:tpep_pickup_datetime,tripinfo:tpep_dropoff_datetime,tripinfo:passenger_count,tripinfo:trip_distance,tripinfo:ratecodeid,tripinfo:store_and_fwd_flag,tripinfo:pulocationid,tripinfo:dolocationid,tripinfo:payment_type,tripinfo:fare_amount,tripinfo:extra,tripinfo:mta_tax,tripinfo:tip_amount,tripinfo:tolls_amount,tripinfo:improvement_surcharge,tripinfo:total_amount,tripinfo:congestion_surcharge,tripinfo:airport_fee,HBASE_ROW_KEY" \
  yellow_tripdata /user/hadoop/nyc_trip_staging_csv_mar_apr



# 5️ Confirm data in HBase
echo "Scan first 10 rows in HBase table $HBASE_TABLE:"
hbase shell <<< "scan '$HBASE_TABLE', {LIMIT => 10}"
